// client/src/api/api.js
import axios from "axios";

// Backend base URL (change if backend hosted elsewhere)
const API = axios.create({
  baseURL: process.env.REACT_APP_API_BASE || "http://localhost:5000/api",
  headers: { "Content-Type": "application/json" }
});

/**
 * fetchRecipes(page, limit, sort, filters)
 * - page, limit are numbers
 * - sort: string e.g. "rating:desc" or "title:asc"
 * - filters: object for title/cuisine etc.
 *
 * Returns the backend response object:
 * { page, limit, total, data: [recipes...] }
 */
export const fetchRecipes = async (page = 1, limit = 15, sort = "rating:desc", filters = {}) => {
  try {
    // merge pagination and filters into params
    const params = { page, limit, sort, ...filters };
    const res = await API.get("/recipes", { params });
    // returns { page, limit, total, data }
    return res.data;
  } catch (err) {
    console.error("fetchRecipes error:", err);
    throw err;
  }
};

export const searchRecipes = async (params = {}) => {
  try {
    // params: { calories, title, cuisine, total_time, rating }
    const res = await API.get("/recipes/search", { params });
    // returns { data: [...] }
    return res.data;
  } catch (err) {
    console.error("searchRecipes error:", err);
    throw err;
  }
};

export const fetchRecipeById = async (id) => {
  try {
    const res = await API.get(`/recipes/${id}`);
    return res.data;
  } catch (err) {
    console.error("fetchRecipeById error:", err);
    throw err;
  }
};

export const addRecipe = async (payload) => {
  try {
    const res = await API.post("/recipes", payload);
    return res.data;
  } catch (err) {
    console.error("addRecipe error:", err);
    throw err;
  }
};

export const updateRecipe = async (id, payload) => {
  try {
    const res = await API.put(`/recipes/${id}`, payload);
    return res.data;
  } catch (err) {
    console.error("updateRecipe error:", err);
    throw err;
  }
};

export const deleteRecipe = async (id) => {
  try {
    const res = await API.delete(`/recipes/${id}`);
    return res.data;
  } catch (err) {
    console.error("deleteRecipe error:", err);
    throw err;
  }
};
