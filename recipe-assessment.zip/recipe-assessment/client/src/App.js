// client/src/App.js
import React from "react";
import RecipeTable from "./components/RecipeTable";

function App() {
  return (
    <div>
      <h1 style={{ textAlign: "center" }}>🍴 Recipe App</h1>
      <RecipeTable />
    </div>
  );
}

export default App;
