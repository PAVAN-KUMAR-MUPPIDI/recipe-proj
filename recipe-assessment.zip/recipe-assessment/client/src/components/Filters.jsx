// client/src/components/Filters.jsx
import React, { useState } from "react";
import { searchRecipes } from "../api/api";

/**
 * Filters component:
 * - title (partial)
 * - cuisine (exact)
 * - calories (<=400 or >=200 etc - user should specify with operator)
 * - rating (>=4.5 etc)
 *
 * Calls searchRecipes with query params and passes results back via setRecipes.
 */
function Filters({ setRecipes }) {
  const [title, setTitle] = useState("");
  const [cuisine, setCuisine] = useState("");
  const [calories, setCalories] = useState("");
  const [rating, setRating] = useState("");

  const handleSearch = async () => {
    try {
      const params = {};
      if (title) params.title = title;
      if (cuisine) params.cuisine = cuisine;
      if (calories) params.calories = calories; // user input should include operator like <=400
      if (rating) params.rating = rating; // operator like >=4.5
      const res = await searchRecipes(params);
      // backend returns { data: [...] }
      setRecipes(res.data || []);
    } catch (err) {
      console.error("Filter search failed", err);
    }
  };

  const handleReset = async () => {
    setTitle(""); setCuisine(""); setCalories(""); setRating("");
    // optionally fetch full list by setting empty array or trigger parent to reload
    setRecipes([]);
  };

  return (
    <div style={{ marginBottom: 12 }}>
      <input style={{margin:"5px"}} placeholder="Title (partial)" value={title} onChange={(e) => setTitle(e.target.value)} />
      <input style={{margin:"5px"}} placeholder="Cuisine (exact)" value={cuisine} onChange={(e) => setCuisine(e.target.value)} />
      <input style={{margin:"5px"}} placeholder="Calories (e.g. <=400)" value={calories} onChange={(e) => setCalories(e.target.value)} />
      <input style={{margin:"5px 25px 5px 5px"}} placeholder="Rating (e.g. >=4.5)" value={rating} onChange={(e) => setRating(e.target.value)} />
      <button style={{cursor:"pointer", margin:"5px"}}  onClick={handleSearch}>Search</button>
      <button style={{cursor:"pointer",margin:"5px"}}  onClick={handleReset}>Reset</button>
    </div>
  );
}

export default Filters;
