// client/src/components/RecipeTable.jsx
import React, { useState, useEffect } from "react";
import { fetchRecipes } from "../api/api";
import RecipeDrawer from "./RecipeDrawer";
import Filters from "./Filters";

/**
 * RecipeTable (main UI)
 * Uses backend fetchRecipes(page,limit,sort,filters)
 */

function RecipeTable() {
  const [recipes, setRecipes] = useState([]);
  const [selected, setSelected] = useState(null);
  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(15);
  const [sort, setSort] = useState("rating:desc");
  const [total, setTotal] = useState(0);

  // initial load or when page/limit/sort changes
  const load = async (p = page, l = limit, s = sort, filters = {}) => {
    try {
      const res = await fetchRecipes(p, l, s, filters);
      // backend returns { page, limit, total, data }
      setRecipes(res.data || []);
      setTotal(res.total || 0);
      setPage(res.page || p);
      setLimit(res.limit || l);
    } catch (err) {
      console.error("Load recipes failed", err);
      setRecipes([]);
    }
  };

  useEffect(() => { load(); }, [page, limit, sort]);

  // setRecipes from Filters will set filtered results; we need to ensure pagination info resets.
  const setFilteredRecipes = (list) => {
    setRecipes(list);
    setPage(1);
    setTotal(list.length);
  };

  return (
    <div style={{ padding: 16 }}>
      <h2>Recipe List</h2>

      <Filters setRecipes={setFilteredRecipes} />

      <div style={{ marginBottom: 8 }}>
        <label>Sort: </label>
        <select value={sort} onChange={(e) => setSort(e.target.value)}>
          <option value="rating:desc">Rating (High → Low)</option>
          <option value="rating:asc">Rating (Low → High)</option>
          <option value="title:asc">Title (A → Z)</option>
          <option value="title:desc">Title (Z → A)</option>
        </select>

        <label style={{ marginLeft: 12 }}>Per page: </label>
        <select value={limit} onChange={(e) => setLimit(Number(e.target.value))}>
          <option value={15}>15</option>
          <option value={25}>25</option>
          <option value={50}>50</option>
        </select>
      </div>

      <table border="1" cellPadding="8" style={{ width: "100%", borderCollapse: "collapse" }}>
        <thead>
          <tr style={{ background: "#f7f7f7" }}>
            <th>Title</th>
            <th>Cuisine</th>
            <th>Rating</th>
            <th>Total Time</th>
            <th>Serves</th>
          </tr>
        </thead>
        <tbody>
          {recipes.length === 0 ? (
            <tr><td colSpan="5" style={{ textAlign: "center", padding: 16 }}>No results found</td></tr>
          ) : (
            recipes.map((r) => (
              <tr key={r._id} style={{ cursor: "pointer" }} onClick={() => setSelected(r._id)}>
                <td style={{ maxWidth: 300, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{r.title}</td>
                <td>{r.cuisine ?? "—"}</td>
                <td>{r.rating ?? "—"}</td>
                <td>{r.total_time ?? "—"} mins</td>
                <td>{r.serves ?? "—"}</td>
              </tr>
            ))
          )}
        </tbody>
      </table>

      <div style={{ marginTop: 12 }}>
        <button disabled={page <= 1} onClick={() => setPage((p) => Math.max(1, p - 1))}>Prev</button>
        <span style={{ margin: "0 8px" }}>Page {page} — Total {total}</span>
        <button disabled={recipes.length < limit} onClick={() => setPage((p) => p + 1)}>Next</button>
      </div>

      {selected && <RecipeDrawer recipeId={selected} onClose={() => setSelected(null)} />}
    </div>
  );
}

export default RecipeTable;
