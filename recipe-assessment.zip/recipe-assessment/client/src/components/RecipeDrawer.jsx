// client/src/components/RecipeDrawer.jsx
import React, { useEffect, useState } from "react";
import { fetchRecipeById } from "../api/api";

/**
 * Drawer that shows recipe details.
 * Props: recipeId, onClose
 */
function RecipeDrawer({ recipeId, onClose }) {
  const [recipe, setRecipe] = useState(null);
  useEffect(() => {
    if (!recipeId) return;
    fetchRecipeById(recipeId).then((data) => setRecipe(data)).catch(console.error);
  }, [recipeId]);

  if (!recipe) {
    return <div style={{ position: "fixed", right: 0, top: 0, width: 300, height: "100%", padding: 20 }}>Loading...</div>;
  }

  const nutrients = recipe.nutrients || {};

  return (
    <div style={{
      position: "fixed",
      right: 0,
      top: 0,
      width: "360px",
      height: "100%",
      background: "#fff",
      padding: 20,
      borderLeft: "1px solid #ddd",
      overflowY: "auto",
      boxShadow: "-2px 0px 8px rgba(0,0,0,0.1)"
    }}>
      <button style={{color:"white",backgroundColor:"#635e59ff",border:"0.2" ,cursor:"pointer"}} onClick={onClose}>Close</button>
      <h2>{recipe.title} <small style={{ fontSize: 12, color: "#666" }}>({recipe.cuisine})</small></h2>
      <p><b>Description:</b> {recipe.description || "—"}</p>
      <p><b>Total Time:</b> {recipe.total_time ?? "—"} mins
        <br />
        <small>Prep: {recipe.prep_time ?? "—"} mins | Cook: {recipe.cook_time ?? "—"} mins</small>
      </p>

      <h3>Nutrients</h3>
      <table style={{ width: "100%", borderCollapse: "collapse" }}>
        <tbody>
          {["calories","carbohydrateContent","cholesterolContent","fiberContent","proteinContent","saturatedFatContent","sodiumContent","sugarContent","fatContent"].map((k) => (
            <tr key={k}>
              <td style={{ borderBottom: "1px solid #eee", padding: "6px 4px", width: "60%" }}>{k}</td>
              <td style={{ borderBottom: "1px solid #eee", padding: "6px 4px" }}>{nutrients[k] ?? "—"}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default RecipeDrawer;
